# phd
for storing commonly used functions in my phd

https://packaging.python.org/en/latest/tutorials/packaging-projects/