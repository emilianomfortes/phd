# phd
for storing commonly used functions in my phd
